SELECT P1.NAZIV, P2.NAZIV
FROM DA.PREDMET AS P1,
     DA.PREDMET AS P2
WHERE P1.ID < P2.ID AND
      P1.ESPB = P2.ESPB AND
      P1.NAZIV LIKE '___ri%' AND
      LENGTH(P2.NAZIV) > 4 AND -- Ili P2.NAZIV LIKE '_____%'
      EXISTS (
          SELECT *
          FROM DA.ISPIT AS I1 JOIN
               DA.ISPIT AS I2 ON I1.INDEKS = I2.INDEKS AND
                                 I1.SKGODINA = I2.SKGODINA
          WHERE I1.IDPREDMETA = P1.ID AND
                I2.IDPREDMETA = P2.ID AND
                I1.STATUS = 'o' AND I1.OCENA > 5 AND
                I2.STATUS = 'o' AND I2.OCENA > 5
      );
