SELECT D.IME || ' ' || D.PREZIME AS "Ime i prezime",
       CASE POL WHEN 'm' THEN 'Student je jedini' ELSE 'Studentkinja je jedina' END ||
       ' iz mesta ' || D.MESTORODJENJA ||
       CASE POL WHEN 'm' THEN ' koji je upisao ' ELSE ' koja je upisala ' END ||
       UG.SKGODINA || '. skolsku godinu' AS "Komentar",
       DAYS_BETWEEN(CURRENT_DATE, D.DATUPISA) AS "Proteklo dana"
FROM DA.DOSIJE AS D JOIN
     DA.UPISGODINE AS UG ON D.INDEKS = UG.INDEKS
WHERE NOT EXISTS (
    SELECT *
    FROM DA.DOSIJE AS DP JOIN
         DA.UPISGODINE AS UGP ON DP.INDEKS = UGP.INDEKS
    WHERE DP.INDEKS <> D.INDEKS AND
          DP.MESTORODJENJA = D.MESTORODJENJA AND
          UGP.SKGODINA = UG.SKGODINA
) AND 5 > (
    SELECT COUNT(*)
    FROM DA.ISPIT AS I JOIN
         DA.PREDMETPROGRAMA AS PP ON I.IDPREDMETA = PP.IDPREDMETA
    WHERE I.INDEKS = D.INDEKS AND
          PP.IDPROGRAMA = D.IDPROGRAMA AND
          PP.VRSTA = 'obavezan' AND
          I.STATUS = 'o' AND
          I.OCENA > 5
)
ORDER BY "Proteklo dana" DESC;
