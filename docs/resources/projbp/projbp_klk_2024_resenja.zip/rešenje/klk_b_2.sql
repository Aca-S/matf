DROP DATABASE IF EXISTS Transakcije;
CREATE DATABASE Transakcije;

USE Transakcije;

CREATE TABLE Klijent(
	sifra INT PRIMARY KEY,
	ime VARCHAR(50) NOT NULL,
	prezime VARCHAR(50) NOT NULL,
	adresa VARCHAR(50) NOT NULL,
	telefon VARCHAR(10),
	email VARCHAR(50),
	UNIQUE(telefon),
	UNIQUE(email)
); -- 

CREATE TABLE IF NOT EXISTS Racun(
    broj_racuna INT PRIMARY KEY,
    sifra_klijenta INT NOT NULL,
    tip_racuna VARCHAR(10) NOT NULL CHECK(tip_racuna in ('tekuci','stedni','kreditni')),
    stanje INT DEFAULT 0,
    CONSTRAINT klijent_fk FOREIGN KEY(sifra_klijenta) REFERENCES Klijent(sifra) ON DELETE CASCADE 
);

CREATE TABLE Transakcija(
	sifra INT PRIMARY KEY,
	racun_posiljaoca INT NOT NULL,
	racun_primaoca INT NOT NULL,
	datum_i_vreme DATETIME NOT NULL,
	iznos INT NOT NULL CHECK(iznos > 0),
	opis_transakcije VARCHAR(300),
	CONSTRAINT posiljalac_fk FOREIGN KEY(racun_posiljaoca) REFERENCES Racun(broj_racuna) ON DELETE CASCADE,
	CONSTRAINT primalac_fk FOREIGN KEY(racun_primaoca) REFERENCES Racun(broj_racuna) ON DELETE CASCADE,
	CONSTRAINT razliciti_racuni_chk CHECK(racun_posiljaoca <> racun_primaoca)
);

ALTER TABLE Klijent
ADD CHECK(telefon is not null or email is not null);

ALTER TABLE Transakcija
DROP COLUMN opis_transakcije;

