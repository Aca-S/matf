DROP DATABASE IF EXISTS Prodavnica;
CREATE DATABASE Prodavnica;

-- Bilo je radova u kojima nije navedena naredna (zakomentarisana) linija, pa je tada neophodno svuda navoditi naziv baze.

-- USE Prodavnica;

CREATE TABLE Prodavnica.Kupac(
	sifra INT NOT NULL PRIMARY KEY,
	ime VARCHAR(50) NOT NULL,
	prezime VARCHAR(50) NOT NULL,
	adresa VARCHAR(50) NOT NULL,
	telefon VARCHAR(10) NOT NULL,
	email VARCHAR(50),
	CONSTRAINT telefon CHECK (telefon is not null),
	UNIQUE(telefon)
);

CREATE TABLE IF NOT EXISTS Prodavnica.Dostavljac(
    jmbg INT PRIMARY KEY,
    broj_vozacke INT(3) NOT NULL,
    kategorija VARCHAR(2),
    ime VARCHAR(50) NOT NULL,
    prezime VARCHAR(50) NOT NULL,
    UNIQUE(broj_vozacke)
);

CREATE TABLE Prodavnica.Dostava(
	id INT PRIMARY KEY AUTO_INCREMENT,
	sifra_kupca INT NOT NULL references Prodavnica.Kupac(sifra) on update cascade,
	jmbg_dostavljaca INT NOT NULL,
	napomena VARCHAR(50),
	adresa VARCHAR(50) NOT NULL,
	status VARCHAR(10) CHECK(status in ('kreirana','spakovana','otkazana', 'zavrsena')) DEFAULT ('kreirana'),
	datum_izmene DATETIME NOT NULL,
	broj_pokusaja INT DEFAULT (0) CHECK(broj_pokusaja >= 0 and broj_pokusaja <= 2),
	-- CONSTRAINT kupac_fk FOREIGN KEY(sifra_kupca) REFERENCES Prodavnica.Kupac(sifra) ON UPDATE CASCADE,
	CONSTRAINT dostavljac_fk FOREIGN KEY (jmbg_dostavljaca) REFERENCES Prodavnica.Dostavljac(jmbg) ON UPDATE CASCADE
);

ALTER TABLE Prodavnica.Kupac
ADD CHECK (email is not null);

-- ALTER TABLE Prodavnica.Kupac
-- MODIFY COLUMN email VARCHAR(50) NOT NULL;

ALTER TABLE Prodavnica.Dostavljac
DROP COLUMN kategorija;



