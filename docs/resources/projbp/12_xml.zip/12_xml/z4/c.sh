xidel b.xml --output-format=xml --xquery \
'count(//Sala[@NazivSale="Marilyn Monroe"]/Projekcija)'