xidel b.xml --output-format=xml --xquery \
'//Avion[@PIBproizvodjac=@PIBvlasnik]'