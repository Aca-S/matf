use office;

set profiling = 1;

-- Ako se proba i ANALYZE i JSON, dobija se naredna greška:
-- This version of MySQL doesn't yet support 'EXPLAIN ANALYZE with JSON format'
EXPLAIN ANALYZE -- format=json
SELECT e.id, e.name, e.surname
FROM Employees AS e
WHERE e.salary = 9000;

-- Treba biti obazriv da kada se korisit ANALYZE, tada se upit zaista i izvrši,
-- za razliku od ostalih formata, gde bude ispisane procene,

CREATE index Employees_salary_index ON Employees(salary) USING btree;

EXPLAIN ANALYZE 
SELECT e.id, e.name, e.surname
FROM Employees AS e
WHERE e.salary = 9000;

DROP index Employees_salary_index ON Employees;

EXPLAIN ANALYZE 
SELECT e.id, e.name, e.surname
FROM Employees AS e
WHERE e.years = 2;

CREATE index Employees_years_index ON Employees (years) USING btree;

EXPLAIN ANALYZE 
SELECT e.id, e.name, e.surname
FROM Employees AS e
WHERE e.years = 2;

DROP index Employees_years_index ON Employees;

show profiles;


-- -----------------------------------------
-- Izlaz ako se navede EXPLAIN FORMAT=JSON
-- -----------------------------------------
-- EXPLAIN
-- {
--   "query_block": {
--     "select_id": 1,
--     "cost_info": {
--       "query_cost": "50725.86"
--     },
--     "table": {
--       "table_name": "e",
--       "access_type": "ALL",
--       "rows_examined_per_scan": 497492,
--       "rows_produced_per_join": 49749,
--       "filtered": "10.00",
--       "cost_info": {
--         "read_cost": "45750.94",
--         "eval_cost": "4974.92",
--         "prefix_cost": "50725.86",
--         "data_read_per_join": "22M"
--       },
--       "used_columns": [
--         "id",
--         "name",
--         "surname",
--         "salary"
--       ],
--       "attached_condition": "(`office`.`e`.`salary` = 9000)"
--     }
--   }
-- }
-- EXPLAIN
-- {
--   "query_block": {
--     "select_id": 1,
--     "cost_info": {
--       "query_cost": "7.94"
--     },
--     "table": {
--       "table_name": "e",
--       "access_type": "ref",
--       "possible_keys": [
--         "Employees_salary_index"
--       ],
--       "key": "Employees_salary_index",
--       "used_key_parts": [
--         "salary"
--       ],
--       "key_length": "4",
--       "ref": [
--         "const"
--       ],
--       "rows_examined_per_scan": 17,
--       "rows_produced_per_join": 17,
--       "filtered": "100.00",
--       "cost_info": {
--         "read_cost": "6.24",
--         "eval_cost": "1.70",
--         "prefix_cost": "7.94",
--         "data_read_per_join": "7K"
--       },
--       "used_columns": [
--         "id",
--         "name",
--         "surname",
--         "salary"
--       ]
--     }
--   }
-- }
-- EXPLAIN
-- {
--   "query_block": {
--     "select_id": 1,
--     "cost_info": {
--       "query_cost": "50725.86"
--     },
--     "table": {
--       "table_name": "e",
--       "access_type": "ALL",
--       "rows_examined_per_scan": 497492,
--       "rows_produced_per_join": 49749,
--       "filtered": "10.00",
--       "cost_info": {
--         "read_cost": "45750.94",
--         "eval_cost": "4974.92",
--         "prefix_cost": "50725.86",
--         "data_read_per_join": "22M"
--       },
--       "used_columns": [
--         "id",
--         "name",
--         "surname",
--         "years"
--       ],
--       "attached_condition": "(`office`.`e`.`years` = 2)"
--     }
--   }
-- }
-- EXPLAIN
-- {
--   "query_block": {
--     "select_id": 1,
--     "cost_info": {
--       "query_cost": "21593.58"
--     },
--     "table": {
--       "table_name": "e",
--       "access_type": "ref",
--       "possible_keys": [
--         "Employees_years_index"
--       ],
--       "key": "Employees_years_index",
--       "used_key_parts": [
--         "years"
--       ],
--       "key_length": "4",
--       "ref": [
--         "const"
--       ],
--       "rows_examined_per_scan": 186636,
--       "rows_produced_per_join": 186636,
--       "filtered": "100.00",
--       "cost_info": {
--         "read_cost": "2929.98",
--         "eval_cost": "18663.60",
--         "prefix_cost": "21593.58",
--         "data_read_per_join": "84M"
--       },
--       "used_columns": [
--         "id",
--         "name",
--         "surname",
--         "years"
--       ]
--     }
--   }
-- }

-- (*1*) Izlaz u slučaju kada se koristi samo format=json.
-- -------------------------------------------------------
-- Query_ID        Duration        Query
-- 1       0.00021950      EXPLAIN format=json
-- SELECT e.id, e.name, e.surname
-- FROM Employees AS e
-- WHERE e.salary = 9000
-- 2       0.81696800      CREATE index Employees_salary_index ON Employees(salary) USING btree
-- 3       0.00029300      EXPLAIN format=json
-- SELECT e.id, e.name, e.surname
-- FROM Employees AS e
-- WHERE e.salary = 9000
-- 4       0.00699600      DROP index Employees_salary_index ON Employees
-- 5       0.00016125      EXPLAIN format=json
-- SELECT e.id, e.name, e.surname
-- FROM Employees AS e
-- WHERE e.years = 2
-- 6       0.81408150      CREATE index Employees_years_index ON Employees (years) USING btree
-- 7       0.00032475      EXPLAIN format=json
-- SELECT e.id, e.name, e.surname
-- FROM Employees AS e
-- WHERE e.years = 2
-- 8       0.00498650      DROP index Employees_years_index ON Employees
-- 
-- --------------------------------------------------------
-- (*2*) Izlaz kada se koristi ANALYZE (realna vremena).
-- --------------------------------------------------------
-- EXPLAIN
-- -> Filter: (e.salary = 9000)  (cost=50726 rows=49749) (actual time=17.7..1349 rows=17 loops=1)
--     -> Table scan ON e  (cost=50726 rows=497492) (actual time=0.019..745 rows=500000 loops=1)
-- EXPLAIN
-- -> Index lookup ON e USING Employees_salary_index (salary=9000)  (cost=7.94 rows=17) (actual time=0.0186..0.13 rows=17 loops=1)
-- EXPLAIN
-- -> Filter: (e.years = 2)  (cost=50726 rows=49749) (actual time=0.0416..1477 rows=99952 loops=1)
--     -> Table scan ON e  (cost=50726 rows=497492) (actual time=0.0124..751 rows=500000 loops=1)
-- EXPLAIN
-- -> Index lookup ON e USING Employees_years_index (years=2)  (cost=21594 rows=186636) (actual time=0.0166..379 rows=99952 loops=1)
-- Query_ID        Duration        Query
-- 1       1.34966575      EXPLAIN ANALYZE 
-- SELECT e.id, e.name, e.surname
-- FROM Employees AS e
-- WHERE e.salary = 9000
-- 2       0.86421075      CREATE index Employees_salary_index ON Employees(salary) USING btree
-- 3       0.00076150      EXPLAIN ANALYZE 
-- SELECT e.id, e.name, e.surname
-- FROM Employees AS e
-- WHERE e.salary = 9000
-- 4       0.00708175      DROP index Employees_salary_index ON Employees
-- 5       1.59895275      EXPLAIN ANALYZE 
-- SELECT e.id, e.name, e.surname
-- FROM Employees AS e
-- WHERE e.years = 2
-- 6       0.83519950      CREATE index Employees_years_index ON Employees (years) USING btree
-- 7       0.50614600      EXPLAIN ANALYZE 
-- SELECT e.id, e.name, e.surname
-- FROM Employees AS e
-- WHERE e.years = 2
-- 8       0.01613950      DROP index Employees_years_index ON Employee

