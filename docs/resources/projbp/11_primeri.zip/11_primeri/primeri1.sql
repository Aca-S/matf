USE office;

SELECT e.id, e.name, e.surname
FROM Employees AS e
WHERE e.id = 500000;

ALTER TABLE Employees ADD CONSTRAINT PRIMARY KEY (id);

explain analyze
SELECT e.id, e.name, e.surname
FROM Employees AS e
WHERE e.id = 500000;

ALTER TABLE Employees drop PRIMARY KEY; 

SHOW profiles;

-- VISUAL EXPLAIN je dostupan u MySQL Workbench-u.
-- Vizuelni prikaz plana izvršavanja može da se dobije i drugim IDE.
-- U alatu DataGrip (JetBrains) postoji mnogo opcija za rad sa dijagramima, kako sa samom shemom, tako i sa planom izvršavanja.
-- Moguće je eksportovati date dijagrame u DOT ili neki drugi format za opis grafova.
-- Pogledati slike.
