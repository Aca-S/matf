-- Koristiti tabelu t kreiranu u primeru sa full-text indeksom (nad office bazom).  

USE office;

START TRANSACTION;

DELETE FROM t;

SELECT * FROM t;

ROLLBACK; 
