-- Koristiti tabelu t kreiranu u primeru sa full-text indeksom (nad office bazom).  

USE office;

START TRANSACTION;  

SELECT id FROM t;  

INSERT INTO t (title, last_used, description) VALUES
('SQL Full Outer Join 1', '2024-04-22', 'Neki opis 1.');

INSERT INTO t (title, last_used, description) VALUES
('SQL Self Join 2', '2024-05-22', 'Neki opis 2.');

COMMIT;  
