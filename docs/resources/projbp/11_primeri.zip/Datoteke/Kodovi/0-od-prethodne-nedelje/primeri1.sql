-- VISUAL EXPLAIN je dostupan u MySQL Workbench-u: 
--   1. Kliknuti na željenu SQL naredbu
--   2. Query -> Explain Current Statement
--   3. Sa desne strane se pojavljuje ikonica "Execution Plan"
-- Prelaskom kursora preko određenog bloka u okviru dijagrama (u vidu tooltipa) se dobija opis operacije koju taj blok predstavlja. Iznad platna na kojem su iscrtani dijagrami, klikom na "View source" se umesto dijagrama prikazuju JSON informacije.
--
-- Vizuelni prikaz plana izvršavanja može da se dobije i u drugim IDE. Alat DataGrip (JetBrains) pruža više opcija za rad sa dijagramima, kako sa samom shemom, tako i sa planom izvršavanja. Moguće je eksportovati dijagrame u DOT ili neki drugi format za opis grafova.

USE office;

SET profiling=1;

SELECT e.id, e.name, e.surname
FROM Employees AS e
WHERE e.id = 500000;

-- Dijagram plana izvršavanja: wb-primeri1_0.png

ALTER TABLE Employees ADD CONSTRAINT PRIMARY KEY (id);

SELECT e.id, e.name, e.surname
FROM Employees AS e
WHERE e.id = 500000;

-- Dijagram plana izvršavanja: wb-primeri1_1.png

ALTER TABLE Employees drop PRIMARY KEY;

SHOW profiles;

-- JSON informacije za naredbu BEZ POSTOJANJA INDEKSA:

-- {
--   "query_block": {
--     "select_id": 1,
--     "cost_info": {
--       "query_cost": "50699.26"
--     },
--     "table": {
--       "table_name": "e",
--       "access_type": "ALL",
--       "rows_examined_per_scan": 497226,
--       "rows_produced_per_join": 49722,
--       "filtered": "10.00",
--       "cost_info": {
--         "read_cost": "45727.00",
--         "eval_cost": "4972.26",
--         "prefix_cost": "50699.26",
--         "data_read_per_join": "22M"
--       },
--       "used_columns": [
--         "id",
--         "name",
--         "surname"
--       ],
--       "attached_condition": "(`office`.`e`.`id` = 500000)"
--     }
--   }
-- }

-- JSON informacije za naredbu SA POSTOJANJEM INDEKSA:

-- {
--   "query_block": {
--     "select_id": 1,
--     "cost_info": {
--       "query_cost": "1.00"
--     },
--     "table": {
--       "table_name": "e",
--       "access_type": "const",
--       "possible_keys": [
--         "PRIMARY"
--       ],
--       "key": "PRIMARY",
--       "used_key_parts": [
--         "id"
--       ],
--       "key_length": "4",
--       "ref": [
--         "const"
--       ],
--       "rows_examined_per_scan": 1,
--       "rows_produced_per_join": 1,
--       "filtered": "100.00",
--       "cost_info": {
--         "read_cost": "0.00",
--         "eval_cost": "0.10",
--         "prefix_cost": "0.00",
--         "data_read_per_join": "472"
--       },
--       "used_columns": [
--         "id",
--         "name",
--         "surname"
--       ]
--     }
--   }
-- }
