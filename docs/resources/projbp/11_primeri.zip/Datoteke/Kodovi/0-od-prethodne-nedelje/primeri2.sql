use office;

set profiling = 1;

-- Statistike u JSON formatu se mogu dobiti i bez grafičkog okruženja:
-- EXPLAIN format=json
SELECT e.id, e.name, e.surname
FROM Employees AS e
WHERE e.salary = 9000;

-- Dijagram plana izvršavanja: wb-primeri2_0.png

-- {
--   "query_block": {
--     "select_id": 1,
--     "cost_info": {
--       "query_cost": "50858.56"
--     },
--     "table": {
--       "table_name": "e",
--       "access_type": "ALL",
--       "rows_examined_per_scan": 498819,
--       "rows_produced_per_join": 49881,
--       "filtered": "10.00",
--       "cost_info": {
--         "read_cost": "45870.37",
--         "eval_cost": "4988.19",
--         "prefix_cost": "50858.56",
--         "data_read_per_join": "22M"
--       },
--       "used_columns": [
--         "id",
--         "name",
--         "surname",
--         "salary"
--       ],
--       "attached_condition": "(`office`.`e`.`salary` = 9000)"
--     }
--   }
-- }

-- Treba biti obazriv da kada se koristi ANALYZE, tada se upit zaista i izvrši, za razliku od ostalih formata, gde budu ispisane procene.
-- NAPOMENA: u nastavku izvršavamo kod direktno iz MySQL Workbench alata, pa nećemo navoditi ključnu reč EXPLAIN.

CREATE index Employees_salary_index ON Employees(salary) USING btree;

SELECT e.id, e.name, e.surname
FROM Employees AS e
WHERE e.salary = 9000;

-- Dijagram plana izvršavanja: wb-primeri2_1.png

-- {
--   "query_block": {
--     "select_id": 1,
--     "cost_info": {
--       "query_cost": "7.94"
--     },
--     "table": {
--       "table_name": "e",
--       "access_type": "ref",
--       "possible_keys": [
--         "Employees_salary_index"
--       ],
--       "key": "Employees_salary_index",
--       "used_key_parts": [
--         "salary"
--       ],
--       "key_length": "4",
--       "ref": [
--         "const"
--       ],
--       "rows_examined_per_scan": 17,
--       "rows_produced_per_join": 17,
--       "filtered": "100.00",
--       "cost_info": {
--         "read_cost": "6.24",
--         "eval_cost": "1.70",
--         "prefix_cost": "7.94",
--         "data_read_per_join": "7K"
--       },
--       "used_columns": [
--         "id",
--         "name",
--         "surname",
--         "salary"
--       ]
--     }
--   }
-- }

DROP index Employees_salary_index ON Employees;

SELECT e.id, e.name, e.surname
FROM Employees AS e
WHERE e.years = 2;

-- Dijagram plana izvršavanja: wb-primeri2_2.png

-- {
--   "query_block": {
--     "select_id": 1,
--     "cost_info": {
--       "query_cost": "50858.56"
--     },
--     "table": {
--       "table_name": "e",
--       "access_type": "ALL",
--       "rows_examined_per_scan": 498819,
--       "rows_produced_per_join": 49881,
--       "filtered": "10.00",
--       "cost_info": {
--         "read_cost": "45870.37",
--         "eval_cost": "4988.19",
--         "prefix_cost": "50858.56",
--         "data_read_per_join": "22M"
--       },
--       "used_columns": [
--         "id",
--         "name",
--         "surname",
--         "years"
--       ],
--       "attached_condition": "(`office`.`e`.`years` = 2)"
--     }
--   }
-- }

CREATE index Employees_years_index ON Employees (years) USING btree;

SELECT e.id, e.name, e.surname
FROM Employees AS e
WHERE e.years = 2;

-- Dijagram plana izvršavanja: wb-primeri2_3.png

-- {
--   "query_block": {
--     "select_id": 1,
--     "cost_info": {
--       "query_cost": "21593.58"
--     },
--     "table": {
--       "table_name": "e",
--       "access_type": "ref",
--       "possible_keys": [
--         "Employees_years_index"
--       ],
--       "key": "Employees_years_index",
--       "used_key_parts": [
--         "years"
--       ],
--       "key_length": "4",
--       "ref": [
--         "const"
--       ],
--       "rows_examined_per_scan": 186636,
--       "rows_produced_per_join": 186636,
--       "filtered": "100.00",
--       "cost_info": {
--         "read_cost": "2929.98",
--         "eval_cost": "18663.60",
--         "prefix_cost": "21593.58",
--         "data_read_per_join": "84M"
--       },
--       "used_columns": [
--         "id",
--         "name",
--         "surname",
--         "years"
--       ]
--     }
--   }
-- }

DROP index Employees_years_index ON Employees;

show profiles;
