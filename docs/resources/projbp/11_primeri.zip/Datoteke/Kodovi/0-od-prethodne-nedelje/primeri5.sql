USE office;
SET profiling = 1;

-- U narednim primerima posmatrati dijagrame plana izvršavanja (iz Workbench ili DataGrip alata).

SELECT e.name, d.mgr
FROM Employees AS e, Departments AS d
WHERE e.did = d.id;

CREATE index Departments_id_index ON Departments (id) USING btree;

SELECT e.name, d.mgr
FROM Employees AS e, Departments AS d
WHERE e.did = d.id;

DROP index Departments_id_index ON Departments;

CREATE index Employees_did_index ON Employees (did) USING btree;

SELECT e.name, d.mgr
FROM Employees AS e, Departments AS d
WHERE e.did = d.id;

DROP index Employees_did_index ON Employees;

/*
Zakljucak: indeksi su znatno usporili spajanje tabela.
*/

ALTER TABLE Departments ADD CONSTRAINT unique_id UNIQUE (id);

SELECT e.name, d.mgr
FROM Employees AS e, Departments AS d
WHERE e.did = d.id;

ALTER TABLE Departments DROP CONSTRAINT unique_id;

ALTER TABLE Employees ADD CONSTRAINT unique_did_id UNIQUE (did, id);

SELECT e.name, d.mgr
FROM Employees AS e, Departments AS d
WHERE e.did = d.id;

/*
Zakljucak: najbolje je napraviti klasterovani indeks nad atributom
spajanja e.did relacije Employees.
*/

ALTER TABLE Employees DROP CONSTRAINT unique_did_id;

DROP TABLE IF EXISTS DepartmentsMem;
CREATE TABLE DepartmentsMem ENGINE=MEMORY AS SELECT * FROM Departments;
-- DROP TABLE IF EXISTS EmployeesMem;
-- CREATE TABLE EmployeesMem ENGINE=MEMORY AS SELECT * FROM Employees;
-- ERROR 1114 (HY000) at line 15: The TABLE 'EmployeesMem' is full
-- SELECT @@max_heap_table_size;
-- +-----------------------+
-- | @@max_heap_table_size |
-- +-----------------------+
-- |              16777216 |
-- +-----------------------+
-- SET max_heap_table_size = 1024*1024*64;
CREATE index DepartmentsMem_id_index ON DepartmentsMem (id) USING HASH;

DROP TABLE IF EXISTS DepartmentsCSV;
CREATE TABLE DepartmentsCSV ENGINE=CSV AS SELECT * FROM Departments;
DROP TABLE IF EXISTS EmployeesCSV;
CREATE TABLE EmployeesCSV ENGINE=CSV AS SELECT * FROM Employees;


-- Nije moguće dodati strani ključ za CSV skladištene tabele:
--  ALTER TABLE EmployeesCSV
--  ADD CONSTRAINT DepID_fk FOREIGN KEY(did) REFERENCES DepartmentsCSV(id)
--       ON DELETE CASCADE;
-- ERROR 1069 (42000) at line 77: Too many keys specified; max 0 keys allowed

-- Za MEMORY je moguće navesti strani ključ, ali će taj ključ biti ignorisan!

DROP TABLE IF EXISTS t1;
DROP TABLE IF EXISTS t2;

CREATE TABLE t1 (a INT NOT NULL, b INT NOT NULL) ENGINE = MEMORY;
CREATE TABLE t2 (c INT NOT NULL, a INT NOT NULL, CONSTRAINT t2_fk FOREIGN KEY(a) REFERENCES t1(a) ON DELETE CASCADE ) ENGINE = MEMORY;

INSERT INTO t1 VALUES (1,1), (2,1), (3,1), (4,1);
INSERT INTO t2 VALUES (1,2), (1,20), (1,2);

DELETE FROM t1 WHERE a = 2;

SELECT * FROM t1;
-- +---+---+
-- | a | b |
-- +---+---+
-- | 1 | 1 |
-- | 3 | 1 |
-- | 4 | 1 |
-- +---+---+
-- 3 rows in SET (0.00 sec)

SELECT * FROM t2;
-- +---+----+
-- | c | a  |
-- +---+----+
-- | 1 |  2 |
-- | 1 | 20 |
-- | 1 |  2 |
-- +---+----+
-- 3 rows in SET (0.00 sec)

-- # Ispis sadržaja foldera sa bazom: #
-- sudo ls -1 /var/lib/mysql/office/
-- total 81440
-- DepartmentsCSV_725.sdi
-- DepartmentsCSV.CSM
-- DepartmentsCSV.CSV
-- Departments.ibd
-- DepartmentsMem_724.sdi
-- EmployeesCSV_726.sdi
-- EmployeesCSV.CSM
-- EmployeesCSV.CSV
-- Employees.ibd

-- Obratimo pažnju da su se pojavili i *.sdi fajlovi. SDI je akronim za serijalizovane rečničke informacije (eng. Serialized Dictionary Information).
-- InnoDB skladišti SDI u drugim fajlovima (zavisno od podešavanja, npr. *.ibd).
-- NDBCLUSTER skladišti SDI podatke u NDB rečnicima.
-- Ostale mašine za skladištenje skladište SDI podatke u .sdi fajlovima koji se kreiraju u direktorijumu gde i ostali fajlovi za tabele date baze.
-- SDI podaci su zapravo u JSON formatu (videti datoteku).


-- # Ispis poslednjih redova CSV fajla koji odgovara DepartmentsCSV tabeli: #
-- sudo tail /var/lib/mysql/office/DepartmentsCSV.CSV
-- 991,"Economy",602378,2,226437,"Nevada"
-- 992,"Development",694361,5,191726,"Wisconsin"
-- 993,"Toy",493058,6,127337,"Arizona"
-- 994,"Furniture",722389,4,96137,"Oregon"
-- 995,"Development",365593,9,339863,"District of Columbia"
-- 996,"Development",961713,2,370353,"Florida"
-- 997,"Appliance",492223,5,81915,"North Carolina"
-- 998,"Economy",322539,6,416282,"Minnesota"
-- 999,"Furniture",255332,4,376239,"Vermont"
-- 1000,"Furniture",934470,7,156097,"Kentucky"



DROP TABLE IF EXISTS t1;
DROP TABLE IF EXISTS t2;

DROP TABLE IF EXISTS DepartmentsMem;
DROP TABLE IF EXISTS DepartmentsMem;
DROP TABLE IF EXISTS DepartmentsCSV;
DROP index DepartmentsMem_id_index ON DepartmentsMem;

SHOW profiles;
