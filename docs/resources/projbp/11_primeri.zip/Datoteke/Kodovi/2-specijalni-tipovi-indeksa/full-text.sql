-- Full-text vrsta indeksa primenljiva je samo nad tipovima:
-- 1. VARCHAR
-- 2. CHAR
-- 3. TEXT

USE office;

DROP TABLE IF EXISTS t;

CREATE TABLE t (
id INT UNSIGNED AUTO_INCREMENT NOT NULL PRIMARY KEY, 
title VARCHAR(200), 
last_used DATE NOT NULL,
description TEXT, 
FULLTEXT(title, description)
) ENGINE = InnoDB;

SHOW INDEXES FROM t;

INSERT INTO t (title, last_used, description) VALUES
('SQL Joins', '2024-03-22', 'An SQL JOIN clause combines rows from two or more tables. It creates a set of rows in a temporary table.'),
('SQL Equi Join', '2024-01-22', 'SQL EQUI JOIN performs a JOIN against equality or matching column(s) values of the associated tables. An equal sign (=) is used as comparison operator in the where clause to refer equality.'),
('SQL Left Join', '2024-02-22', 'The SQL LEFT JOIN, joins two tables and fetches rows based on a condition, which is matching in both the tables and the unmatched rows will also be available from the table before the JOIN clause.'),
('SQL Cross Join', '2024-03-23', 'The SQL CROSS JOIN produces a result set which is the number of rows in the first table multiplied by the number of rows in the second table, if no WHERE clause is used along with CROSS JOIN.'),
('SQL Full Outer Join', '2024-01-23', 'In SQL the FULL OUTER JOIN combines the results of both left and right outer joins and returns all (matched or unmatched) rows from the tables on both sides of the join clause.'),
('SQL Self Join', '2024-02-23', 'A self join is a join in which a table is joined with itself (which is also called Unary relationships), especially when the table has a FOREIGN KEY which references its own PRIMARY KEY.');

-- Da dobijemo sve redove koji imaju nekog poklapanja:
SELECT * FROM t WHERE MATCH(title, description) AGAINST ('left right' IN NATURAL LANGUAGE MODE);

-- Da dobijemo koeficijent preklapanja sa redovima sa kojima postoji poklapanje:
SELECT id, MATCH(title, description) AGAINST ('left right' IN NATURAL LANGUAGE MODE) AS score FROM t;

-- Operatori + i - (negacija i konjukcija/presek):
SELECT * FROM t WHERE MATCH(title, description) AGAINST ('+left +right' IN BOOLEAN MODE);
