-- Primer sa funkcionalnim indeksima.
-- Koristiti tabelu t kreiranu u primeru sa full-text indeksom (nad office bazom).  

USE office;

SELECT * FROM t;

ALTER TABLE t ADD INDEX func_ind_month ((MONTH(last_used)));

SELECT * FROM t WHERE MONTH(last_used) = 3;

ALTER TABLE t DROP INDEX func_ind_month;

ALTER TABLE t ADD INDEX func_ind_join ((SUBSTRING(title, -4, 4)));

SELECT * FROM t WHERE SUBSTRING(title, -4, 4) = 'Join';

ALTER TABLE t DROP INDEX func_ind_join;

SHOW profiles;
