USE office;

SELECT count(*), job, location FROM Employees group by job, location;

ALTER TABLE Employees ADD INDEX job_location_years (job, location, years);

-- Proverite plan izvršavanja sledećih upita:

SELECT * FROM Employees WHERE job = 'Actor';
SELECT * FROM Employees WHERE location = 'Maryland';
-- Zbog prirode strukture stabla, u narednom slučaju nije moguće iskoristiti prethodno definisani indeks.
SELECT * FROM Employees WHERE job = 'Actor' OR location = 'Maryland';
-- Ukoliko je uslov u WHERE klauzi sačinjen od atributa koji zajedno sačinjavaju levi prefiks kompozitnog indeksa, za taj uslov je moguće iskoristiti indeks!
-- S obzirom da je AND komutativni operator, redosled navođenja atributa  sa leve i desne strane tog operatora nema uticaja na mogućnost iskorišćavanja indeksa od strane optimizatora.
SELECT * FROM Employees WHERE location = 'Maryland' AND job = 'Actor';
SELECT * FROM Employees WHERE job = 'Actor' AND location = 'Maryland' AND years = 2;
SELECT * FROM Employees WHERE (job = 'Musician' OR job = 'Actor') AND location = 'Maryland' AND years >= 2;
SELECT * FROM Employees WHERE job = 'Musician' OR (job = 'Actor' AND location = 'Maryland');


ALTER TABLE Employees DROP INDEX job_location_years;

SHOW profiles;
