-- Primer index-only strategije. U MySQL/InnoDB se naziva pokrivajućim indeksom ("covering index").
-- Koristiti tabelu t kreiranu u primeru sa full-text indeksom (nad office bazom).  

USE office;

UPDATE Employees
SET age = 30 + FLOOR(RAND() * 50)
WHERE job = 'Actor';

UPDATE Employees
SET age = 23 + FLOOR(RAND() * 50)
WHERE job = 'Medical student';

-- Kada se koristi index-only strategija, u okviru "Extra" kolone treba da piše "Using index".
-- U narednom primeru to neće biti slučaj:
EXPLAIN
SELECT AVG(age), job
FROM Employees
WHERE years=4
GROUP BY job;

-- Pogledajmo sve postojeće indekse u office bazi.
-- To može biti korisno ukoliko je potrebno referisati se na naziv indeksa koji nije imenovan.

SELECT table_schema, table_name, index_name, column_name
FROM information_schema.statistics
WHERE non_unique = 1 AND table_schema = "office"; 

-- Prilikom dodavanja kompozitnih indeksa i razmatranja često korišćenih upita, prvi po redu (levlji) treba da budu oni koji se pojavljuju u WHERE klauzi, pa u GROUP BY, pa u SELECT delu.

ALTER TABLE Employees
ADD INDEX years_job_age (years, job, age);

SELECT table_schema, table_name, index_name, column_name
FROM information_schema.statistics
WHERE non_unique = 1 AND table_schema = "office"; 

-- Naredni upit koristi index-only strategiju.
-- U to se možemo uveriti tako što vidimo da u "Extra" koloni piše "Using index".
EXPLAIN
SELECT AVG(age), job
FROM Employees
WHERE years=4
GROUP BY job;


-- Svi sekundarni indeksi (tj. svi sem jednog koji je klasterovan), automatski uključuju i atribute primarnog ključa.
-- Stoga se i oni mogu koristiti u okviru index-only strategije.
-- Posmatrajmo naredni primer:
DESCRIBE Employees;
ALTER TABLE Employees ADD PRIMARY KEY (id);
DESCRIBE Employees;

-- Da bismo se uverili da se neki indeks ne koristi, možemo koristiti EXPLAIN, pa uočiti da u sadržaju 'Extra' kolone nije navedeno da se koristi određeni indeks.
-- Drugi način je posmatranje plana izvršavanja (ili u 'Query Stats' prikazu Workbencha videti: 'Index Usage: No Index used').
EXPLAIN 
SELECT count(id)
FROM Employees
WHERE location = 'New York';

-- Dodajmo sada i indeks po koloni lokacija:
ALTER TABLE Employees
ADD INDEX ind_location (location);

-- Pokretanjem istog upita, koristiće se index-only strategija:
EXPLAIN 
SELECT count(id)
FROM Employees
WHERE location = 'New York';

-- Zaključak: primarni ključ jeste deo sekundarnog indeksa 'ind_location'.


-- Prilikom kreiranja upita, treba razmišljati o projekciji kolona iz rezultata koji je zaista potreban.
-- Ukoliko se vraćaju i neki podaci koji nisu neophodni, treba razmisliti o prepisivanju upita sa manjim brojem izdvojenih koloni.
-- Sa minimalnim brojem kolona će možda biti moguće i ubrzati izračunavanje korišćenjem index-only strategije.
EXPLAIN
SELECT *
FROM Employees
WHERE job = 'Actor'; -- Extra: 'Using where'

-- Ako je u praksi dovoljno raditi nad kolonom 'age', upit treba transformisati.

EXPLAIN
SELECT age
FROM Employees
WHERE job = 'Actor'; -- Extra: 'Using where; Using index for skip scan'

ALTER TABLE Employees
ADD INDEX job_age (job, age);

-- Dodavanjem prethodnog indeksa, koristiće se index-only strategija.
EXPLAIN
SELECT age
FROM Employees
WHERE job = 'Actor'; -- Extra: 'Using index' 

ALTER TABLE Employees DROP PRIMARY KEY;
ALTER TABLE Employees DROP INDEX years_job_age;
ALTER TABLE Employees DROP INDEX job_age;

SHOW profiles;


-- Pre nego što se opredelimo za index-only strategiju treba sagledati naredne osobine upita.
-- 1. Pokrivajući indeksi dupliciraju podatke iz originalne tabele, pa u slučaju velikih tabela i indeks može zauzimati dosta prostora.
-- 2. Dokle god je broj kolona neophodnih za upit mali ova strategija može biti dobra, ali treba razmatrati i tendenciju potrebe za dodatnim brojem kolona.
