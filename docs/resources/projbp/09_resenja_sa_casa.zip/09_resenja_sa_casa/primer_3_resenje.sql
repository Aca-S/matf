-- Date su tabele PERSONS, EMPLOYEES i STUDENTS

CREATE TABLE persons(
	ssn INT NOT NULL PRIMARY KEY,
	name VARCHAR(20) NOT NULL
);

CREATE TABLE employees(
	ssn INT NOT NULL PRIMARY KEY,
	company VARCHAR(20) NOT NULL,
	salary DECIMAL(9, 2),
	FOREIGN KEY (ssn) REFERENCES persons(ssn)
		ON DELETE CASCADE ON UPDATE RESTRICT
);

CREATE TABLE students(
	ssn INT NOT NULL PRIMARY KEY,
	university VARCHAR(20) NOT NULL,
	major VARCHAR(20),
	FOREIGN KEY (ssn) REFERENCES persons(ssn)
		ON DELETE CASCADE ON UPDATE RESTRICT
);

-- Zadatak1: Napraviti pogled `info` koji spaja ove podatke u jedno
-- Motivacija: Spajanje ovih tabela u jedno moze biti zahtevno, 
-- tako da pravimo pogled
-- Napomena: Ako zaista zelimo da dobijemo na efikasnosti, trebao bi nam materijalizovani pogled

-- Studentski kod

CREATE VIEW info AS
SELECT	p.ssn, p.name, e.company, e.salary, s.university, s.major FROM persons p
		LEFT JOIN employees e ON p.ssn = e.ssn
		LEFT JOIN students s ON s.ssn = p.ssn;

-- Zadatak2: Ne mozemo brisati iz prethodno definisanog pogleda
-- Napraviti okidac `info_delete` koji omogucava brisanje iz pogleda
-- preko kolone `ssn`

-- Studentski kod

--#SET TERMINATOR $

CREATE TRIGGER info_delete INSTEAD OF DELETE ON info
REFERENCING OLD AS o
FOR EACH ROW MODE DB2SQL
BEGIN ATOMIC

DELETE FROM persons
WHERE ssn = o.ssn;

END$

--#SET TERMINATOR ;

-- Zadatak3: Ne mozemo da dodajemo nove redove 
-- u prethodno definisanom pogledu
-- Napraviti okidac `info insert` koji omogucava dodavanje redova u pogled,
-- a samim tim i indirektno dodavanje u tabele

-- Studentski kod

--#SET TERMINATOR $

CREATE TRIGGER info_insert INSTEAD OF INSERT ON info
REFERENCING NEW AS n
FOR EACH ROW MODE DB2SQL
BEGIN ATOMIC

INSERT INTO persons
VALUES (n.ssn, n.name);

IF n.company IS NOT NULL THEN
	INSERT INTO employees
	VALUES (n.ssn, n.company, n.salary);
END IF;

IF n.university IS NOT NULL THEN
	INSERT INTO students
	VALUES (n.ssn, n.university, n.major);
END IF;

END$

--#SET TERMINATOR ;

-- Zadatak4: Ne mozemo da menjamo vrednosti redova
-- u prethodno definisanom pogledu
-- Napraviti okidac `info update` koji omogucava azuriranje redova u pogled,
-- a samim tim i indirektno azuriranje u tabelama

-- Studentski kod

--#SET TERMINATOR $

CREATE TRIGGER info_update INSTEAD OF UPDATE ON info
REFERENCING OLD AS o NEW AS n
FOR EACH ROW MODE DB2SQL
BEGIN ATOMIC

DELETE FROM info
WHERE ssn = o.ssn;

INSERT INTO info
VALUES (n.ssn, n.name, n.company, n.salary, n.university, n.major);

END$

--#SET TERMINATOR ;

-- Testiranje
-- INSERT:
INSERT INTO info VALUES
	(123456, 'Smith', NULL, NULL, NULL, NULL),
	(234567, 'Jones', 'Wmart', 20000, NULL, NULL),
	(345678, 'Miller', NULL, NULL, 'Harvard', 'Math'),
	(456789, 'McNuts', 'SelfEmp', 60000, 'UCLA', 'CS');
  
SELECT * FROM info;

-- DELETE
DELETE FROM info
WHERE ssn = 456789;

SELECT * FROM info;

-- UPDATE
UPDATE info SET 
	ssn = 654321,
	name = 'Smith', 
	company = 'SamSvojGazda', 
	salary = 100000, 
	university = 'Gigatrend', 
	major = 'Menadzment'
WHERE ssn = 234567;

SELECT * FROM info;

SELECT * FROM persons;
SELECT * FROM employees;
SELECT * FROM students;

-- Ciscenje
DROP VIEW info;
DROP TRIGGER info_delete;
DROP TRIGGER info_insert;
DROP TRIGGER info_update;
DROP TABLE persons;
DROP TABLE employees;
DROP TABLE students;