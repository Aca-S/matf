SET ENCRYPTION PASSWORD '123456';

CREATE TABLE users
(
	user VARCHAR(20),
	system VARCHAR(30),
	login VARCHAR(20),
	password VARCHAR(40) FOR BIT DATA
);

CREATE VIEW my_logins(system, login, password) AS
SELECT system, login, decrypt_char(password)
FROM users WHERE user = USER;

--#SET TERMINATOR $

CREATE TRIGGER my_logins_insert INSTEAD OF INSERT ON my_logins
REFERENCING NEW AS n
FOR EACH ROW MODE DB2SQL
BEGIN

INSERT INTO users
VALUES (USER, n.system, n.login, encrypt(n.password));

END$

--#SET TERMINATOR ;

--#SET TERMINATOR $

CREATE TRIGGER my_logins_update INSTEAD OF UPDATE ON my_logins
REFERENCING NEW AS n OLD AS o
FOR EACH ROW MODE DB2SQL
BEGIN

UPDATE users SET
	system = n.system,
	login = n.login,
	password = encrypt(n.password)
WHERE
	user = USER AND
	system = o.system AND
	login = o.login;

END$

--#SET TERMINATOR ;

INSERT INTO my_logins VALUES
	('AFS', 'srielau', 'mydogsname'),
	('Linux', 'root', 'oopsIforgot'),
	('IIUG', 'Rielau', '123456789');
	
SELECT * FROM my_logins;

SELECT * FROM users;

DROP TRIGGER my_logins_update;
DROP TRIGGER my_logins_insert;

DROP VIEW my_logins;

DROP TABLE users;