drop database vezbe;
create database if not exists vezbe character set = utf8;
use vezbe;

create table original(val int primary key);

create table kopija(k_val int);

delimiter $$

-- Zameniti linije za testiranje
-- create trigger kopiraj after insert on original
create trigger kopiraj before insert on original
for each row
begin
    insert into kopija set k_val = new.val;
end$$

delimiter ;

-- Testiranje
insert into original values (1), (2), (3);

insert ignore into original values (4), (1);

select * from original\G
select '-------------------------------------------------';
select * from kopija\G
